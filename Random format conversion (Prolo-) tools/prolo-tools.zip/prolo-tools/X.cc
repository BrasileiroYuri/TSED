#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

int main() {
  string inp, outp;
  int level=0, words=0;
  bool none = 1; int del=0;
  while (cin >> inp) {
    assert (inp!="");
    if ((outp.size() == 0) && 
	((inp == "(") || (inp == "(TOP"))) {
      del=1;
    }
    else if (inp[0] == '(') {
      level++;
      if (outp.size() > 0) outp+= " ";
      outp+= inp;
    }
    else {
      assert (inp[inp.size()-1] == ')' );
      for (int k=inp.size()-1; k>=0; k--)
	if (inp[k] == ')' )
	  level--;
      assert (level >= -1);
      if (level<0) { 
	inp = inp.substr (0, inp.size()-1);
	level++;
      }
      if (outp.size() > 0) outp+= " ";
      outp+= inp;
      
      if (level==0) {
	cout << outp << endl;
	words=0;
	outp="";
	none=0;
	del=0;
      }
    }
  }
}

