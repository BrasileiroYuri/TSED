#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

int main() {
  string inp, outp, last;
  int level=0, words=0;
  bool none = 1;
  while (cin >> inp) {
    assert (inp!="");
    if (inp[0] == '(') {
      while (inp[0] == '(') {
	level++;
	inp = inp.substr (1, inp.size()-1); 
      }
      last = inp;
      none = (inp == "-NONE-");
    }
    else {
      assert (inp[inp.size()-1] == ')' );
      while (inp[inp.size()-1] == ')' ) {
	level--;
	inp = inp.substr (0, inp.size()-1);
      }
      //      if ((inp.size()>0) && (inp[0] != '*')) {
      if ((inp.size()>0) && (!none)) {
	if (words != 0) outp+= " ";
	outp+= "(" + inp + " (" + last + "))";
	words++;
      }
      if (level==0) {
	cout << "(" << outp << ")" << endl;
	words=0;
	outp="";
	none=0;
      }
    }
  }
}

