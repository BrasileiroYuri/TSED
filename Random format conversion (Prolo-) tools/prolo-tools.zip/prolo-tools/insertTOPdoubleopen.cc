#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <string>

using namespace std;

int main() {
  string inp, outp;
  int level=0, words=0;
  bool none = 1;
 
  while (getline (cin, inp)) {
    if (inp=="") continue;
    inp= inp.substr (2, inp.size()-2);
    cout << "(TOP " << inp << " )" << endl;
  }

}
