#include <iostream>
#include <stdlib.h>
#include <assert.h>
#include <string>

using namespace std;

int main() {
  string inp, outp;
  int level=0, words=0;
  bool none = 1;
 
  while (getline (cin, inp)) {
    assert (inp!="");
    cout << "(TOP " << inp << " )" << endl;
  }

}
