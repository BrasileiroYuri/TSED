#include <iostream>
#include <stdlib.h>
#include <assert.h>

using namespace std;

int main() {
  string inp, outp;
  int level=0, words=0;
  const int extrapar=0, TOP=1, singlepar=2;
  bool none = 1; int kind;
  while (cin >> inp) {
    assert (inp!="");
    if (outp.size() == 0) {
      assert (inp[0] == '(');
      level++;
      if (inp == "(TOP") {
	kind=TOP; // Nothing to do
	outp=inp;
      }
      else if ((inp.size() == 1)) {
	outp = "(TOP";
	kind = extrapar; // Nothing else to do
      }
      else if (inp[1] == '(') {
	level++;
	outp = "(TOP " + inp.substr (1, inp.size()-1);
	kind = extrapar; // Nothing else to do
      }
      else {
	outp = "(TOP " + inp;
	kind = singlepar; // Should insert par at the end
      }
    }
    else if (inp[0] == '(') {
      level++;
      outp+= " " + inp;
    }
    else {
      assert (inp[inp.size()-1] == ')' );
      for (int k=inp.size()-1; k>=0; k--)
	if (inp[k] == ')' )
	  level--;
      assert (level >= 0);
      if (outp.size() > 0) outp+= " ";
      outp+= inp;
      
      if (level==0) {
	if (kind == singlepar) outp += " )";
	cout << outp << endl;
	words=0;
	outp="";
	none=0;
      }
    }
  }
}

